=== MastrLab 4.0 ===
Contributors: MastrLab
Tags: audio, mastering, web audio, wavesurfer, mp3, wav
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 4.0.0
License: GPLv2 or later

Shortcode: [mastrlab]

This plugin provides a modern in‑browser mastering UI inspired by top mastering suites.
Upload a WAV/MP3, tweak knobs in real time (WebAudio), preview the waveform, and export WAV/MP3.
